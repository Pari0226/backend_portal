from app import create_app, db
from app.models import User

app = create_app()
app.app_context().push()

user = User.query.filter_by(email="pari.ops@example.com").first()
if user:
    user.role = 'ops'
    db.session.commit()
    print("✅ User role updated to ops")
else:
    print("❌ User not found")
