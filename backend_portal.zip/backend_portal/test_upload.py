import requests

# Step 1: Login to get JWT
login_url = 'http://localhost:5000/auth/login'
login_data = {
    'email': 'pari.ops@example.com',
    'password': 'secure123'
}


login_resp = requests.post(login_url, json=login_data)
print("Login Response:", login_resp.status_code, login_resp.json())

if login_resp.status_code != 200:
    exit("❌ Login failed, check credentials.")

token = login_resp.json()['access_token']

# Step 2: Upload a file
upload_url = 'http://localhost:5000/upload'
headers = {'Authorization': f'Bearer {token}'}
files = {
    'file': open('sample_upload.docx', 'rb')
}
upload_resp = requests.post(upload_url, headers=headers, files=files)

print("Upload Status:", upload_resp.status_code)
try:
    print("Response:", upload_resp.json())
except Exception:
    print("Raw Response:", upload_resp.text)
