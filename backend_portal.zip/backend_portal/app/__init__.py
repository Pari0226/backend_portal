from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
from flask_mail import Mail
from dotenv import load_dotenv
import os

db = SQLAlchemy()
jwt = JWTManager()
mail = Mail()

def create_app():
    load_dotenv()
    app = Flask(__name__)

    # Config
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY')
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///project.db'
    app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY')

    # Email Config
    app.config['MAIL_SERVER'] = 'smtp.gmail.com'
    app.config['MAIL_PORT'] = 587
    app.config['MAIL_USE_TLS'] = True
    app.config['MAIL_USERNAME'] = os.getenv('MAIL_USERNAME')
    app.config['MAIL_PASSWORD'] = os.getenv('MAIL_PASSWORD')

    # Initialize extensions
    db.init_app(app)
    jwt.init_app(app)
    mail.init_app(app)

    # Register Blueprints
    from app.routes.auth import auth_bp
    from app.routes.file_routes import file_bp
    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(file_bp)  # Routes like /upload and /download/<token>

    # Load models after app is ready
    from app import models

    return app
