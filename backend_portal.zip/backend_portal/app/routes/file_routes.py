from flask import Blueprint, request, jsonify, send_from_directory
from flask_jwt_extended import jwt_required, get_jwt_identity
from werkzeug.utils import secure_filename
import os
from app.models import File, User
from app.utils.token import generate_file_token, verify_file_token
from app import db

file_bp = Blueprint('file', __name__)

# ✅ Allowed extensions
ALLOWED_EXTENSIONS = {'pptx', 'docx', 'xlsx'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@file_bp.route('/upload', methods=['POST'])
@jwt_required()
def upload_file():
    user_id = int(get_jwt_identity())
    current_user = User.query.get(user_id)

    if not current_user:
        return jsonify({'error': 'User not found'}), 404

    if current_user.role != 'ops':
        return jsonify({'error': 'Only ops users can upload files'}), 403

    if 'file' not in request.files:
        return jsonify({'error': 'No file part in the request'}), 400

    file = request.files['file']

    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)

        # Create uploads directory if it doesn't exist
        upload_folder = os.path.join('app', 'uploads')
        os.makedirs(upload_folder, exist_ok=True)

        file_path = os.path.join(upload_folder, filename)
        file.save(file_path)

        # Save file metadata to DB
        new_file = File(
            filename=filename,
            uploader_id=user_id
        )
        db.session.add(new_file)
        db.session.commit()

        # 🔐 Generate encrypted token for secure client download
        file_token = generate_file_token(new_file.id)
        new_file.encrypted_token = file_token
        db.session.commit()

        return jsonify({
            'message': 'File uploaded successfully',
            'download_token': file_token
        }), 201

    return jsonify({'error': 'Invalid file type'}), 400

@file_bp.route('/download/<token>', methods=['GET'])
@jwt_required()
def download_file(token):
    user_id = int(get_jwt_identity())
    current_user = User.query.get(user_id)

    # ✅ Allow only verified client users
    if not current_user or current_user.role != 'client' or not current_user.is_verified:
        return jsonify({'error': 'Access denied'}), 403

    file_id = verify_file_token(token)
    if not file_id:
        return jsonify({'error': 'Invalid or expired download link'}), 400

    file = File.query.get(file_id)
    if not file:
        return jsonify({'error': 'File not found'}), 404

    file_path = os.path.join('app', 'uploads')
    return send_from_directory(directory=file_path, path=file.filename, as_attachment=True)
