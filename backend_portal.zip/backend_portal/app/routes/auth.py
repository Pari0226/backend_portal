from flask import Blueprint, request, jsonify
from werkzeug.security import generate_password_hash
from flask_jwt_extended import create_access_token
from app.models import User
from app import db
from app.utils.token import generate_token, verify_token

auth_bp = Blueprint('auth', __name__)

# ✅ Signup Route
@auth_bp.route('/signup', methods=['POST'])
def signup():
    data = request.get_json()

    name = data.get('name')
    email = data.get('email')
    password = data.get('password')

    if not name or not email or not password:
        return jsonify({'error': 'Please fill in all fields.'}), 400

    existing_user = User.query.filter_by(email=email).first()
    if existing_user:
        return jsonify({'error': 'Email already exists.'}), 409

    new_user = User(name=name, email=email, role='client', is_verified=False)
    new_user.set_password(password)

    db.session.add(new_user)
    db.session.commit()

    # 🔐 Generate verification token and link
    token = generate_token(email)
    verify_url = f"http://localhost:5000/auth/verify-email/{token}"

    return jsonify({
        'message': 'Signup successful! Please verify your email.',
        'verify_url': verify_url
    }), 201

# ✅ Email Verification Route
@auth_bp.route('/verify-email/<token>', methods=['GET'])
def verify_email(token):
    email = verify_token(token)
    if not email:
        return jsonify({'error': 'Invalid or expired verification link'}), 400

    user = User.query.filter_by(email=email).first()
    if not user:
        return jsonify({'error': 'User not found'}), 404

    if user.is_verified:
        return jsonify({'message': 'Email already verified'}), 200

    user.is_verified = True
    db.session.commit()

    return jsonify({'message': 'Email verified successfully!'}), 200

# ✅ Login Route
@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()

    email = data.get('email')
    password = data.get('password')

    if not email or not password:
        return jsonify({'error': 'Email and password are required'}), 400

    user = User.query.filter_by(email=email).first()

    if not user or not user.check_password(password):
        return jsonify({'error': 'Invalid email or password'}), 401

    if not user.is_verified:
        return jsonify({'error': 'Please verify your email before logging in'}), 403

    access_token = create_access_token(identity=str(user.id))

    return jsonify({'access_token': access_token}), 200
