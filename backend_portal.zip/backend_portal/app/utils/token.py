from itsdangerous import URLSafeTimedSerializer, URLSafeSerializer
import os

# Use fallback secret if env is not set (optional safety net)
SECRET_KEY = os.getenv('SECRET_KEY') or "fallback-secret"

# ✅ Email verification token (with expiry and salt)
def generate_token(email):
    serializer = URLSafeTimedSerializer(SECRET_KEY)
    return serializer.dumps(email, salt='email-confirm')

def verify_token(token, max_age=3600):
    serializer = URLSafeTimedSerializer(SECRET_KEY)
    try:
        email = serializer.loads(token, salt='email-confirm', max_age=max_age)
        return email
    except Exception:
        return None

# ✅ File download token (no salt, no expiry)
file_serializer = URLSafeSerializer(SECRET_KEY)

def generate_file_token(file_id):
    return file_serializer.dumps(file_id)

def verify_file_token(token):
    try:
        return file_serializer.loads(token)
    except Exception:
        return None
