import requests

url = "http://localhost:5000/auth/signup"

data = {
    "name": "Pari Ops",
    "email": "pari.ops@example.com",   # 👈 use a new unique email
    "password": "secure123"
}

response = requests.post(url, json=data)

print("Status Code:", response.status_code)
try:
    print("Response:", response.json())
except:
    print("Non-JSON Response:", response.text)
