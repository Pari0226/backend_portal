import requests

url = "http://localhost:5000/auth/login"

data = {
    "email": "parisingh02@example.com",   # use the same email you just verified
    "password": "secure123"               # use the same password you signed up with
}

response = requests.post(url, json=data)

print("Status Code:", response.status_code)
print("Response:", response.json())
