import requests

# Replace with valid client credentials
login_data = {
    "email": "pari.ops@example.com",
    "password": "secure123"
}

login_resp = requests.post("http://localhost:5000/auth/login", json=login_data)
token = login_resp.json()["access_token"]

headers = {
    "Authorization": f"Bearer {token}"
}

# Replace with actual download token from file upload
download_token = "Mg.OE91DqIA0Bum2CRnBd7Nc4zEZK8"


url = f"http://localhost:5000/download/{download_token}"
resp = requests.get(url, headers=headers)

# Save downloaded file if successful
if resp.status_code == 200:
    with open("downloaded_file.docx", "wb") as f:
        f.write(resp.content)
    print("✅ File downloaded successfully.")
else:
    print("❌ Error:", resp.status_code, resp.text)
